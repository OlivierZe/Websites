<?php
        
    // Session Handling

    session_start();

    if(session_destroy())
    {
        header("Location: index.php");
    }

?>